A Pen created at CodePen.io. You can find this one at https://codepen.io/mrhuggies/pen/mBOpxY.

 An earlier version of my current portfolio. Didnt really want to delete it after I forked so kept it here